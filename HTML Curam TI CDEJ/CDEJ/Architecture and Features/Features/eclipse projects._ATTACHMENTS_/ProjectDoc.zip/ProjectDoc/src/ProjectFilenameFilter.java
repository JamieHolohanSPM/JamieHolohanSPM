import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ProjectFilenameFilter {
    
    public List<File> finder(String dirName){

        List<File> files = new ArrayList<File>();        
        listf(dirName, files);
        return files;
    }
    
    public void listf(String dirName, List<File> files) {

    	File directory = new File(dirName);
		File[] fList = directory.listFiles();
        for (File file : fList) {
            if (file.isFile() && file.getName().endsWith(".project")) {
                files.add(file);
            } else if (file.isDirectory()) {
                listf(file.getAbsolutePath(), files);
            }
        }
    }
    

}
