import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class ProjectDocMain {

	private static final String PROJECTS_ROOT_DIR = "/Users/conor/RTC-Dev/cd_TI_7010dec2/TI";

	// some configurable parts of the graphviz output
	private static final boolean forceShowDuplicateEdges = false;
	private static final boolean mergeDuplicateEdges = true;
	private static final boolean clustered = false;
	
	private static final String[] highlight = { "adbuildtools", "AppInf", "client-inf",
	"client-persistence", "commons-testing", "CoreInf",
	"dom-html-xim", "duim-generator", "general-plug-ins",
	"Generator", "JDECommons", "plug-in-core", "plug-in-framework",
	"renderer-model", "renderer-plug-ins", "resource-manager",
	"ServerCore", "TabTestClient", "TabTestServer",
	"test-framework", "TestModel", "Tooling", "UnitTests",
	"word-file-edit" };

	private static final String[] server = { "AppInf", "CuramSDEJ",
			"ServerCore", "GenericSearchServer", "WebLogic", "Websphere",
			"CuramSDEJ", "envvars", "EJBServerShoeSize", "GSSUnitTests",
			"ModelTestFramework", "TestModel", "TestModelClient" };

	private static final String[] client = { "CuramCDEJ", "BrowserPlugins", "CuramFlexInfTest",
		"client-inf", "client-persistence", "dom-html-xim",
		"general-plug-ins", "helptools", "mobile-sdk",
		"plug-in-framework", "renderer-plug-ins", "test-framework",
		"word-file-edit", "CoreInf", "dojo-overrides", "Generator",
		"Sandbox", "TextHelperGenerator", "commons-testing",
		"duim-generator", "renderer-model", "resource-manager",
		"CuramCDEJ", "ClientMockApp", "CuramSampleMobileApp",
		"TabTestServer", "TabTestClient" };

	private static final String[] both = { "JDE Build Scripts", "JDECommons", "plug-in-core",
		"curam.ide.internal.tooling", "curam.ide.modeling.profile",
		"curam.ide.modeling.rsm", "adbuildtools", "post-processing",
		"pre-processing", "policing", "udp", "UnitTests", "Tooling" };

	private static final String[] leftovers = { "TI", "NewDashboard",
			".org.eclipse.jdt.core.external.folders", "RemoteSystemsTempFiles",
			"ReleaseNotes", "UpgradeHelper", "GeneratorValidationTests" };
	
	private static DocumentBuilder dBuilder;
	
	private static Map<String, String> nameToLocation;
	
	private static List<String> allProjects;

	

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException {

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dBuilder = dbFactory.newDocumentBuilder();		
		nameToLocation = new HashMap<String, String>();
        allProjects = new ArrayList<String>();
				
		List<File> files = new ProjectFilenameFilter().finder(PROJECTS_ROOT_DIR);
		
		List<ProjectDescription> projectDescList = getAllProjectDescriptions(files);
//
//		List<File> cpfiles = new ArrayList<File>();
//		for (File file : files) {
//			cpfiles.add(new File(file.getParent() + ".classpath"));
//		}
		getAllClasspathDescriptions(projectDescList);

		System.out.println("-------------------------ALL------------------------------");
		print_graphviz(projectDescList, allProjects);

		System.out.println("-----------------------SERVER-----------------------------");
		List<String> serverAndBoth = Arrays.asList(generalConcatAll(server, both));
		print_graphviz(projectDescList, serverAndBoth);
		
		System.out.println("------------------------CLIENT----------------------------");
		List<String> clientAndBoth = Arrays.asList(generalConcatAll(client, both));
		print_graphviz(projectDescList, clientAndBoth);
		  

	}

	private static void print_graphviz(
			List<ProjectDescription> projectDescList, List<String> includeList) {

		System.out.println("digraph g{");
		System.out.println("rankdir=RL;");
		System.out.println("node [fontname = \"Helvetica-Outline\" ];");
		System.out.println();

		if (clustered) {
			print_graphviz_cluster("Server", Arrays.asList(server), includeList);
			print_graphviz_cluster("Common", Arrays.asList(both), includeList);
			print_graphviz_cluster("Client", Arrays.asList(client), includeList);
			//print_graphviz_projects(Arrays.asList(leftovers));
		} else {
			print_graphviz_projects(includeList);
		}
		print_graphviz_edges(projectDescList, includeList);

		System.out.println("}");

	}

	private static void print_graphviz_cluster(String name, List<String> clusterList, List<String> totalIncludeList) {
		
		System.out.println("subgraph cluster" + name + " {");
		System.out.println("label = \"" + name + "\";");
		System.out.println("style=filled;");
		System.out.println("color=lightgrey;");
		System.out.println("node [style=filled,color=white];");
		
		List<String> hList = Arrays.asList(highlight);
		for (String i: clusterList) {
			if (totalIncludeList.contains(i)) {
				if (hList.contains(i)) {
				  System.out.println("\"" + i + "\" [style=filled, color=yellow];");				
				} else {
				  System.out.println("\"" + i + "\";"); 
				}
			}
		}

		System.out.println("}");
		
	}

	private static void print_graphviz_projects(List<String> includeList) {
		 

		List<String> hList = Arrays.asList(highlight);
		List<String> sList = Arrays.asList(server);
		List<String> bList = Arrays.asList(both);
		List<String> cList = Arrays.asList(client);
		
		for (String i: includeList) {
			
			String color = "";
			if (sList.contains(i)) {
				color = ", color=red";
			} else if (bList.contains(i)) {
				color = ", color=blue";
			} else if (cList.contains(i)) {
				color = ", color=green";
			}
			
			if (hList.contains(i)) {
			  System.out.println("\"" + i + "\" [style=filled" + color + ", fillcolor=yellow];");				
			} else {
			  System.out.println("\"" + i + "\";"); 
			}
		}
	}

	private static void print_graphviz_edges(
			List<ProjectDescription> projectDescList, List<String> includeList) {

		for (ProjectDescription d : projectDescList) {

			if (includeList.contains(d.getName())) {

				// DEBUGGING OUTPUT
				// System.out.println(PROJECTS_ROOT_DIR + File.separator +
				// d.getLocation() + File.separator + ".classpath");

				// 1. loop through the .project dependencies
				for (String p : d.getProjectNames()) {

					if (includeList.contains(p)) {

						// if the dependency is both project and classpath, make
						// the
						// edge blue
						if (mergeDuplicateEdges
								&& d.getProjectNamesInClasspath().contains(p)) {
							System.out.println("\"" + d.getName() + "\" -> \""
									+ p + "\" [color=\"0.649 0.701 0.701\"];");
						} else {
							System.out.println("\"" + d.getName() + "\" -> \""
									+ p + "\"");
							// System.out.println("\"" + d.getName() + " (" +
							// d.getLocation() + ")\" -> \"" + p + " (" +
							// nameToLocation.get(p.toLowerCase()) + ")\"");
						}
					}
				}
				
				// 2. loop through the .classpath dependencies
				for (String c : d.getProjectNamesInClasspath()) {

					if (includeList.contains(c)) {

						// if the dependency is both project and classpath don't
						// re-add it unless force is set
						if (forceShowDuplicateEdges
								|| !d.getProjectNames().contains(c)) {
							System.out.println("\"" + d.getName() + "\" -> \""
									+ c + "\" [color=\"0.348 0.839 0.839\"];");
						}
					}
				}
			}
		}
	}


	
	private static void print_yFilesGraphBuilder(
			List<ProjectDescription> projectDescList) {
		
		for (Entry<String, String> entry : nameToLocation.entrySet()) {
			System.out.print("'" + entry.getKey() + " (" + entry.getValue()
					+ ")', ");
		}
		System.out.println("");

		for (ProjectDescription d : projectDescList) {
			for (String p : d.getProjectNames()) {
				System.out.println("{from:'" + d.getName() + " ("
						+ d.getLocation() + ")', to:'" + p + " ("
						+ nameToLocation.get(p.toLowerCase()) + ")'},");
			}
		}

	}

	private static List<ProjectDescription> getAllProjectDescriptions(List<File> files) throws ParserConfigurationException, XPathExpressionException, SAXException, IOException {
		
		List<ProjectDescription> projectDescList = new ArrayList<ProjectDescription>();	
		
		for (File f: files) {	
			ProjectDescription projectDescFromFile = getProjectDescFromFile(f);
			if (projectDescFromFile != null) {
			  projectDescList.add(projectDescFromFile);
			}
		}
		return projectDescList;
	}

	private static ProjectDescription getProjectDescFromFile(File f) throws SAXException, IOException, XPathExpressionException {
		
		//System.out.println("Processing " + f.getAbsolutePath());
		
		ProjectDescription desc = new ProjectDescription();
		desc.setLocation(f.getAbsolutePath().replaceFirst(PROJECTS_ROOT_DIR, "").replaceFirst("/", "").replaceAll("/.project", "").replaceAll("/template.project", ""));
		
		Document doc = dBuilder.parse(f);
		doc.getDocumentElement().normalize();
		
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		
		XPathExpression nameExpr = xpath.compile("/projectDescription/name/text()");
		NodeList nameList = (NodeList) nameExpr.evaluate(doc, XPathConstants.NODESET);
		if (nameList.getLength() != 1) {
		  System.out.println("ERROR:- Project file missing project name: " + f.getAbsolutePath());
          return null;			
		}
		desc.setName(nameList.item(0).getNodeValue());
		nameToLocation.put(desc.getName().toLowerCase(), desc.getLocation());
		allProjects.add(desc.getName());
		
		XPathExpression projExpr = xpath.compile("/projectDescription/projects/project/text()");
		NodeList projList = (NodeList) projExpr.evaluate(doc, XPathConstants.NODESET);
		
		for(int i=0; i<projList.getLength() ; i++) {
			desc.getProjectNames().add( projList.item(i).getNodeValue() );
        }
		
		return desc;
	}
	

	private static void getAllClasspathDescriptions(List<ProjectDescription> projectDescList) throws ParserConfigurationException, XPathExpressionException, SAXException, IOException {
				
		for (ProjectDescription desc: projectDescList) {	
			updateProjectWithClasspathRefsFromFile(desc);
		}
	}

	private static void updateProjectWithClasspathRefsFromFile(ProjectDescription desc) throws SAXException, IOException, XPathExpressionException {
		
		File classpathFile = new File(new File(PROJECTS_ROOT_DIR + File.separator + desc.getLocation()) + File.separator + ".classpath");
		//System.out.println("Processing " + classpathFile.getCanonicalPath());
		
		if (!classpathFile.exists()) {
			return;
		}
		
		Document doc = dBuilder.parse(classpathFile);
		doc.getDocumentElement().normalize();
		
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		
		XPathExpression pathExpr = xpath.compile("/classpath/classpathentry[@path!='']/@path");
		NodeList pathList = (NodeList) pathExpr.evaluate(doc, XPathConstants.NODESET);
		
		for(int i=0; i<pathList.getLength() ; i++) {
		  String path = pathList.item(i).getNodeValue();
		  if (path.startsWith("/")) {
			  path = path.substring(1);
		  }

//		  int j = 0;
//		  if (path.contains("Tooling")) {
//			  j++;
//		  }
//		  System.out.println(j);
		  
		  String[] split = path.split("/");
		  if (split.length > 0) {
			  path = split[0];
			  
			  
			  if (nameToLocation.keySet().contains(path.toLowerCase())) {
			    desc.getProjectNamesInClasspath().add(path);
			  }
		  }
        }
		
	}
	

    public static String[] generalConcatAll(String[]... jobs) {
        int len = 0;
        for (final String[] job : jobs) {
            len += job.length;
        }

        final String[] result = new String[len];

        int currentPos = 0;
        for (final String[] job : jobs) {
            System.arraycopy(job, 0, result, currentPos, job.length);
            currentPos += job.length;
        }

        return result;
    }

}
