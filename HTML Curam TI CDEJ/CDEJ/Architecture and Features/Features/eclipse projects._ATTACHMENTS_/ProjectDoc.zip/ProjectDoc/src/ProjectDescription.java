import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class ProjectDescription {
	private String location;
	private String name;
	private List<String> readmeContents;
	private Set<String> projectNames;
	private Set<String> projectNamesInClasspath;
	
	public ProjectDescription() {
		readmeContents = new ArrayList<String>();
		projectNames = new TreeSet<String>();
		projectNamesInClasspath = new TreeSet<String>();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<String> getProjectNames() {
		return projectNames;
	}
	public Set<String> getProjectNamesInClasspath() {
		return projectNamesInClasspath;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<String> getReadmeContents() {
		return this.readmeContents;		
	}
	public void setReadmeContents(List<String> readmeContents) {
		this.readmeContents = readmeContents;		
	}
	
      
}
