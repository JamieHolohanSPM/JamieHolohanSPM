/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization;

import org.owasp.html.HtmlChangeListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Listener created to detected whether elements/attributes were discarded from
 * a given input.
 */
public final class MaliciousContentListener
        implements HtmlChangeListener<Void> {

    /**
     * Discarded attributes/elements will be added in this map.
     */
    private final Map<String, Integer> strippedContentMap = new HashMap<>();

    /**
     * Invoked when a tag is stripped out.
     *
     * @param context {@link Void} instance
     * @param tag     {@link String} element name
     */
    public void discardedTag(
            final Void context,
            final String tag) {
        Integer value = getSanitizedCount(tag);
        strippedContentMap.put(tag, ++value);
    }

    /**
     * Invoked when an attribute is stripped out.
     *
     * @param context    {@link Void} instance
     * @param tag        {@link String} element name
     * @param attributes {@link java.util.List} list of attributes
     */
    public void discardedAttributes(
            final Void context,
            final String tag, final String... attributes) {
        for (final String attribute : attributes) {
            Integer value = getSanitizedCount(attribute);
            strippedContentMap.put(attribute, ++value);
        }
    }

    /**
     * Return true if any element/attribute was stripped out of the input.
     *
     * @return {@link Boolean} instance
     */
    public boolean isSanitized() {
        return !strippedContentMap.isEmpty();
    }

    /**
     * Return how many instances of the given element/attribute was stripped out
     * of the given input.
     *
     * @param key {@link String} any given element/attribute
     * @return {@link Integer} discarded count
     */
    public Integer getSanitizedCount(final String key) {
        return strippedContentMap.getOrDefault(key, 0);
    }

    /**
     * Clear the stripped content map. Can be used between NON_STRICT_JSON sanitizing operations for a blank slate before each execution.
     */
    public void clear() {
        strippedContentMap.clear();
    }

}
