package curam.cirrus.client.util;

import curam.util.sanitization.InputSanitizer;
import curam.util.sanitization.MaliciousContentListener;
import curam.util.sanitization.SanitizationUtils;
import curam.util.sanitization.constants.ContentType;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;

/**
 * Class responsible for testing data sanitization scenarios, which is important
 * to prevent malicious users from exploiting XSS vulnerabilities. The main
 * usages of sanitize related methods happens in:
 *
 * <pre>
 * <b>inbound:</b> curam.cirrus.client.uim2.servlet.filter.ParameterSanitisationFilter
 * <b>outbound:</b> curam.cirrus.client.uim2.jackson.serializer.SanitisedStringSerializer
 * </pre>
 *
 * @author romulo
 */
public class SanitizerSuite {

    static List<String> xssVectors;

    static List<String> harmlessJsonList;

    static List<String> harmlessElementsList;

    static List<String> harmlessAttributesList;

    static List<String> maliciousJsonList;

    static List<String> maliciousElementsList;

    static List<String> maliciousAttributesList;

    @BeforeClass
    public static void loadResources() throws IOException {

        xssVectors = read("xss.vectors.txt");

        harmlessJsonList = read("harmless.json.txt");

        harmlessElementsList = read("harmless.elements.txt");

        harmlessAttributesList = read("harmless.attributes.txt");

        maliciousJsonList = read("malicious.json.txt");

        maliciousElementsList = read("malicious.elements.txt");

        maliciousAttributesList = read("malicious.attributes.txt");

    }

    private static List<String> read(String resource) throws IOException {

        final URL url = SanitizerSuite.class.getClassLoader()
                .getResource(resource);

        return IOUtils.readLines(url.openStream(), Charset.defaultCharset());

    }

    @Test
    public void testHarmlessJSON() {

        for (final String input : harmlessJsonList) {
            final MaliciousContentListener listener = new MaliciousContentListener();
            final String output = SanitizationUtils.sanitiseData(input,
                    listener);
            Assert.assertEquals(input, output);
            Assert.assertFalse(listener.isSanitized());
        }

    }

    @Test
    public void testMaliciousJSON() {

        InputSanitizer inputSanitizer = ContentType.STRICT_JSON.getSanitizer();

        for (final String input : maliciousJsonList) {
            final String output = inputSanitizer.sanitize(input);
            Assert.assertFalse(input.equals(output));
        }

    }

    @Test(timeout = 5000)
    /**
     * Testing the performance on moderate complexity texts (130k+).
     */
    public void testHTMLPerformance() {

        InputSanitizer inputSanitizer = ContentType.TEXT_HTML.getSanitizer();

        for (int i = 0; i < 100; i++) {
            for (final String input : xssVectors) {
                inputSanitizer.sanitize(input);
            }
        }
    }

    @Test(timeout = 5000)
    /**
     * Testing the performance on moderate complexity JSON (60k).
     */
    public void testNonStrictJsonPerformance() {

        InputSanitizer inputSanitizer = ContentType.NON_STRICT_JSON.getSanitizer();

        for (int i = 0; i < 10000; i++) {
            for (final String input : maliciousJsonList) {
                inputSanitizer.sanitize(input);
            }
        }
    }

    @Test(timeout = 5000)
    /**
     * Testing the performance on moderate complexity JSON (60k).
     */
    public void testStrictJsonPerformance() {

        InputSanitizer inputSanitizer = ContentType.STRICT_JSON.getSanitizer();

        for (int i = 0; i < 10000; i++) {
            for (final String input : maliciousJsonList) {
                inputSanitizer.sanitize(input);
            }
        }
    }

    @Test
    public void testMaliciousElements() {

        for (final String input : maliciousElementsList) {
            final MaliciousContentListener listener = new MaliciousContentListener();
            final String output = SanitizationUtils.sanitiseData(input,
                    listener);
            Assert.assertFalse(input.equals(output));
            Assert.assertTrue(listener.isSanitized());
        }

    }

    @Test
    public void testMaliciousAttributes() {

        for (final String input : maliciousAttributesList) {
            final MaliciousContentListener listener = new MaliciousContentListener();
            final String output = SanitizationUtils.sanitiseData(input,
                    listener);
            Assert.assertFalse(input.equals(output));
            Assert.assertTrue(listener.isSanitized());
        }

    }

    @Test
    public void testHarmlessAttributes() {

        for (final String input : harmlessAttributesList) {
            final MaliciousContentListener listener = new MaliciousContentListener();
            SanitizationUtils.sanitiseData(input, listener);
            Assert.assertFalse(listener.isSanitized());
        }

    }

    @Test
    public void testHarmlessElements() {

        for (final String input : harmlessElementsList) {
            final MaliciousContentListener listener = new MaliciousContentListener();
            String output = SanitizationUtils.sanitiseData(input, listener);
            Assert.assertTrue(input.equals(output));
            Assert.assertFalse(listener.isSanitized());
        }

    }

    @Test
    public void testVectors() {

        InputSanitizer sanitizer = ContentType.TEXT_HTML.getSanitizer();

        for (final String input : xssVectors) {
            final String output = sanitizer.sanitize(input);
            Assert.assertFalse(input.equals(output));
        }
    }

    @Test
    public void testWhitespaceRemoval() {
        final String input = "<br  />";
        final MaliciousContentListener listener = new MaliciousContentListener();
        final String output = SanitizationUtils.sanitiseData(input,
                listener);
        Assert.assertFalse(input.equals(output));
        Assert.assertFalse(listener.isSanitized());
    }

}
