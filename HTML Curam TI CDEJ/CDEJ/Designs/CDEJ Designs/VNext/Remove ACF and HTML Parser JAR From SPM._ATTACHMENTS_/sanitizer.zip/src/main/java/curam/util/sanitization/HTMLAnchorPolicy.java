/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization;

import org.owasp.html.ElementPolicy;

import java.util.List;

/**
 * Custom {@link ElementPolicy} for HTML anchor elements.
 */
public final class HTMLAnchorPolicy implements ElementPolicy {

    /**
     * Constant for anchor elements.
     */
    public static final String ELEMENT_NAME = "a";

    /**
     * Singleton instance field.
     */
    private static HTMLAnchorPolicy instance = new HTMLAnchorPolicy();

    /**
     * Private constructor.
     */
    private HTMLAnchorPolicy() {

    }

    /**
     * Return the singleton instance.
     *
     * @return {@link HTMLAnchorPolicy} instance
     */
    public static HTMLAnchorPolicy getInstance() {
        return instance;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.owasp.html.ElementPolicy#apply(java.lang.String, java.util.List)
     */
    public String apply(final String elementName, final List<String> attrs) {
        attrs.add("target");
        attrs.add("_blank");
        return elementName;
    }

}
