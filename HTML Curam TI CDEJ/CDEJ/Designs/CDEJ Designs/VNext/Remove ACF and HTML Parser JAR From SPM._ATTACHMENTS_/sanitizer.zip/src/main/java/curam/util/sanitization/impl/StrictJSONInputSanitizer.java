/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import curam.util.sanitization.InputSanitizer;
import curam.util.sanitization.json.SanitisedObjectMapper;
import org.owasp.html.HtmlChangeListener;

import javax.annotation.concurrent.ThreadSafe;
import java.util.Map;

/**
 * Input is deserialized into a map using a {@link SanitisedObjectMapper} instance and then re-serialized, triggering a hierarchically-aware sanitization of the keys/string values. This sanitizer is slower than {@link JSONInputSanitizer} but the JSON generated is always reliable, regardless on how complex the input is.
 */
@ThreadSafe
public class StrictJSONInputSanitizer implements InputSanitizer {

    /**
     * Class-level singleton mapper.
     */
    static SanitisedObjectMapper SANITIZER_MAPPER = new SanitisedObjectMapper();

    /**
     * Optional instance-level custom sanitizer mapper.
     */
    private SanitisedObjectMapper customSanitizerMapper;

    /**
     * Default constructor.
     */
    public StrictJSONInputSanitizer() {
        this(null);
    }

    /**
     * Advanced constructor.
     *
     * @param listener {@link HtmlChangeListener} instance
     */
    public StrictJSONInputSanitizer(HtmlChangeListener listener) {
        if (listener != null) {
            this.customSanitizerMapper = new SanitisedObjectMapper(listener);
        }
    }

    @Override
    public String sanitize(String input) {
        try {
            Map<String, Object> jsonAsMap = getMapper().readValue(input, Map.class);
            return getMapper().writeValueAsString(jsonAsMap);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Return the instance-level sanitizer case it's not null, otherwise the class-level singleton is returned.
     *
     * @return {@link ObjectMapper} instance
     */
    private ObjectMapper getMapper() {
        if (customSanitizerMapper != null) {
            return customSanitizerMapper;
        }
        return SANITIZER_MAPPER;
    }

}
