/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.impl;

import curam.util.sanitization.InputSanitizer;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.html.HtmlChangeListener;

import javax.annotation.concurrent.ThreadSafe;

import static curam.util.sanitization.constants.SanitizationConstants.*;

/**
 * The logic applied is the same as {@link HTMLInputSanitizer}, however an additional fixup is applied in an attempt to preserve the JSON syntax. Advantage of this method is improved performance but depending on the input complexity it can generate mal-formed JSON.
 */
@ThreadSafe
public class JSONInputSanitizer implements InputSanitizer {

    /**
     * Optional listener.
     */
    HtmlChangeListener listener;

    /**
     * Default constructor.
     */
    public JSONInputSanitizer() {
        this(null);
    }

    /**
     * Advanced constructor.
     *
     * @param listener {@link HtmlChangeListener} instance
     */
    public JSONInputSanitizer(HtmlChangeListener listener) {
        this.listener = listener;
    }

    @Override
    public String sanitize(String input) {

        input = StringEscapeUtils.unescapeHtml4(input);

        String output = POLICY_FACTORY.sanitize(input, listener, null);

        output = StringUtils.replaceChars(output, DOUBLE_QUOTES, SINGLE_QUOTES);

        output = StringEscapeUtils.unescapeHtml4(output);

        return StringUtils.replaceChars(output, SINGLE_QUOTES, DOUBLE_QUOTES);

    }

}
