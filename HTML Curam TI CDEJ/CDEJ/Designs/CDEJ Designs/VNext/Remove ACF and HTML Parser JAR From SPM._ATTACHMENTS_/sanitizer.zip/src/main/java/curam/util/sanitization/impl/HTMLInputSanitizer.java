/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.impl;

import curam.util.sanitization.InputSanitizer;
import curam.util.sanitization.constants.SanitizationConstants;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.html.HtmlChangeListener;

import javax.annotation.concurrent.ThreadSafe;

/**
 * Fastest sanitizer available. Input is unescaped and then sanitized using the default policy. The output of the sanitization process is then unescaped again to ensure the HTML syntax.
 */
@ThreadSafe
public class HTMLInputSanitizer implements InputSanitizer {

    /**
     * Optional listener.
     */
    HtmlChangeListener listener;

    /**
     * Default constructor.
     */
    public HTMLInputSanitizer() {
        this(null);
    }

    /**
     * Advanced constructor.
     *
     * @param listener {@link HtmlChangeListener} instance
     */
    public HTMLInputSanitizer(HtmlChangeListener listener) {
        this.listener = listener;
    }

    @Override
    public String sanitize(String input) {

        input = StringEscapeUtils.unescapeHtml4(input);

        String output = SanitizationConstants.POLICY_FACTORY.sanitize(input, listener, null);

        return StringEscapeUtils.unescapeHtml4(output);

    }

}
