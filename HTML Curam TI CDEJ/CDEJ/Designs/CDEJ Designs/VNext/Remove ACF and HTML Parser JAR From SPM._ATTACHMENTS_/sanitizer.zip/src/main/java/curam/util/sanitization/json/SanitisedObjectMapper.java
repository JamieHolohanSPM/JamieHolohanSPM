/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.json;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import curam.util.sanitization.constants.ContentType;
import org.owasp.html.HtmlChangeListener;

/**
 * Custom Jackson object mapper created to automatically apply the sanitization methods on {@link ContentType#NON_STRICT_JSON} key/value pairs during the serialization process.
 */
public class SanitisedObjectMapper extends ObjectMapper {

    /**
     * Serial version.
     */
    private static final long serialVersionUID = -1L;

    /**
     * Advanced constructor which accepts an instance of {@link HtmlChangeListener}. The listener is invoked every time a tag/element is discarded during the sanitization process.
     *
     * @param listener {@link HtmlChangeListener} instance
     */
    public SanitisedObjectMapper(HtmlChangeListener listener) {

        final SimpleModule module = new SimpleModule();

        module.addKeySerializer(String.class, new SanitisedKeySerializer(listener));

        module.addSerializer(String.class, new SanitisedStringSerializer(listener));

        this.registerModule(module);

    }

    /**
     * Default constructor.
     */
    public SanitisedObjectMapper() {
        this(null);
    }

}
