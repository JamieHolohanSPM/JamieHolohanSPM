/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization;

import curam.util.sanitization.constants.ContentType;
import org.apache.commons.lang3.StringUtils;
import org.apache.wink.json4j.JSONArray;
import org.apache.wink.json4j.JSONObject;
import org.owasp.html.HtmlChangeListener;

/**
 * Class responsible for executing data sanitization which is important
 * to prevent malicious users from exploiting XSS vulnerabilities.
 */
public abstract class SanitizationUtils {

    /**
     * Sanitize the input using the more appropriate sanitizer available.
     *
     * @param input {@link String} any given string
     * @return {@link String} sanitized output
     */
    public static String sanitiseData(final String input) {
        return sanitiseData(input, true, null);
    }

    /**
     * Sanitize the input using the more appropriate sanitizer available.
     *
     * @param input     {@link String} any given string
     * @param useStrict {@link Boolean} flag which dictates if a stricter sanitizer is preferred.
     * @return {@link String} sanitized output
     */
    public static String sanitiseData(final String input, boolean useStrict) {
        return sanitiseData(input, useStrict, null);
    }

    /**
     * Sanitize the input using the more appropriate sanitizer available.
     *
     * @param input    {@link String} any given string
     * @param listener {@link HtmlChangeListener} instance
     * @return {@link String} sanitized output
     */
    public static String sanitiseData(final String input, HtmlChangeListener listener) {
        return sanitiseData(input, true, listener);
    }

    /**
     * Sanitize the input using the more appropriate sanitizer available.
     *
     * @param input     {@link String} any given string
     * @param useStrict {@link Boolean} flag which dictates if a stricter sanitizer is preferred.
     * @param listener  {@link HtmlChangeListener} instance
     * @return {@link String} sanitized output
     */
    public static String sanitiseData(final String input, boolean useStrict, HtmlChangeListener listener) {

        if (StringUtils.isBlank(input)) {
            return input;
        }

        if (isValidJSON(input)) {

            InputSanitizer inputSanitizer = useStrict ? ContentType.STRICT_JSON.getSanitizer(listener) :
                    ContentType.NON_STRICT_JSON.getSanitizer(listener);

            return inputSanitizer.sanitize(input);

        }

        return ContentType.TEXT_HTML.getSanitizer(listener).sanitize(input);

    }

    /**
     * Return true if the input is a valid JSON (array or object) or false otherwise.
     *
     * @param input {@link String} any given string
     * @return {@link Boolean} instance
     */
    public static boolean isValidJSON(String input) {
        if (StringUtils.isBlank(input)) {
            return false;
        }
        return isValidJSONObject(input) || isValidJSONArray(input);
    }

    /**
     * Return true if the input is a valid JSON Array or false otherwise.
     *
     * @param input {@link String} any given string
     * @return {@link Boolean} instance
     */
    private static boolean isValidJSONArray(String input) {
        try {
            new JSONArray(input);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    /**
     * Return true if the input is a valid JSON Object or false otherwise.
     *
     * @param input {@link String} any given string
     * @return {@link Boolean} instance
     */
    private static boolean isValidJSONObject(String input) {
        try {
            new JSONObject(input);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

}
