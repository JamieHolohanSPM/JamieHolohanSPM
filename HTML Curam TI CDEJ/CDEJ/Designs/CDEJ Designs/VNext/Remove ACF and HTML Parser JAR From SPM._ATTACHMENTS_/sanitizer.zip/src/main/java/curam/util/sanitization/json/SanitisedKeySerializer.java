/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import curam.util.sanitization.constants.ContentType;
import org.owasp.html.HtmlChangeListener;

import javax.annotation.Nullable;
import java.io.IOException;

/**
 * Custom serializer created to sanitize {@link ContentType#NON_STRICT_JSON} keys.
 */
public class SanitisedKeySerializer extends JsonSerializer<String> {

    /**
     * Optional listener.
     */
    @Nullable
    final HtmlChangeListener listener;

    /**
     * Default constructor.
     *
     * @param listener {@link HtmlChangeListener} instance
     */
    public SanitisedKeySerializer(HtmlChangeListener listener) {
        this.listener = listener;
    }

    @Override
    public void serialize(String input, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {

        String output = ContentType.TEXT_HTML.getSanitizer(listener).sanitize(input);

        jsonGenerator.writeFieldName(output);

    }

}
