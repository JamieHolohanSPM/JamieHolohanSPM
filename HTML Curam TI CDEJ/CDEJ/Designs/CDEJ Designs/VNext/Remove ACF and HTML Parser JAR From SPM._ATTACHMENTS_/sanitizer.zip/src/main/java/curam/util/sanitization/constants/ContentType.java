/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.constants;

import curam.util.sanitization.InputSanitizer;
import curam.util.sanitization.impl.HTMLInputSanitizer;
import curam.util.sanitization.impl.JSONInputSanitizer;
import curam.util.sanitization.impl.StrictJSONInputSanitizer;
import org.owasp.html.HtmlChangeListener;

/**
 * Enumeration of content types supported by the sanitizer.
 */
public enum ContentType {

    /**
     * Non-strict JSON content type.
     */
    NON_STRICT_JSON {
        @Override
        public InputSanitizer getSanitizer(HtmlChangeListener listener) {
            return new JSONInputSanitizer(listener);
        }
    },
    /**
     * Text/HTML content type.
     */
    TEXT_HTML {
        @Override
        public InputSanitizer getSanitizer(HtmlChangeListener listener) {
            return new HTMLInputSanitizer(listener);
        }
    },
    /**
     * Strict JSON content type.
     */
    STRICT_JSON {
        @Override
        public InputSanitizer getSanitizer(HtmlChangeListener listener) {
            return new StrictJSONInputSanitizer(listener);
        }
    };

    /**
     * Return the appropriate {@link InputSanitizer} implementation.
     *
     * @param listener {@link HtmlChangeListener} optional listener
     * @return {@link InputSanitizer} instance
     */
    public abstract InputSanitizer getSanitizer(HtmlChangeListener listener);

    /**
     * Return the appropriate {@link InputSanitizer} implementation.
     *
     * @return {@link InputSanitizer} instance
     */
    public InputSanitizer getSanitizer() {
        return getSanitizer(null);
    }

}
