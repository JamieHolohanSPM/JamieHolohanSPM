/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization;

import curam.util.sanitization.constants.ContentType;

/**
 * Interface which should be implemented by input sanitizers. Use {@link ContentType} to return the implementations.
 */
public interface InputSanitizer {

    /**
     * Execute the sanitization process in the given input.
     *
     * @param input {@link String} any given string
     * @return {@link String} sanitized output
     */
    String sanitize(String input);

}
