/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * Copyright IBM Corporation 2019.
 *
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the US
 * Copyright Office.
 */
package curam.util.sanitization.constants;

import curam.util.sanitization.HTMLAnchorPolicy;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.owasp.html.Sanitizers;

import javax.annotation.concurrent.ThreadSafe;

/**
 * Constants used by the sanitization utility.
 */
@ThreadSafe
public abstract class SanitizationConstants {

    /**
     * Sanitize policy used to prevent malicious code injection.
     */
    public static final PolicyFactory POLICY_FACTORY = new HtmlPolicyBuilder()
            .allowElements(HTMLAnchorPolicy.getInstance(),
                    HTMLAnchorPolicy.ELEMENT_NAME)
            .toFactory()
            .and(Sanitizers.BLOCKS).and(Sanitizers.FORMATTING)
            .and(Sanitizers.IMAGES).and(Sanitizers.LINKS).and(Sanitizers.TABLES);

    /**
     * Single quotes character.
     */
    public static final String SINGLE_QUOTES = "\'";

    /**
     * Double quotes character.
     */
    public static final String DOUBLE_QUOTES = "\"";

}
